from menu.main import *
__version__ = "1.0.2"
__author__ = 'Ben Smith'
