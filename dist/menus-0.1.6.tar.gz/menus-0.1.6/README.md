# Menus
Easy CLI menu creation tool

# Example
```py
>>> from menus import *
>>> answer = menu(title='Menu',options=['option1','option2'], result='index')
[+] Menu        [1] option1     [2] option2

(Menu) > 1
>>> print(answer)
1
```
