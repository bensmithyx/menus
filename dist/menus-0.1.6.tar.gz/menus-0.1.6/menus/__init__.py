from menus.main import *
__version__ = "0.1.6"
__author__ = 'Ben Smith'
