# menus
Easy CLI menu creation tool

# Example
```answer = menu(title='Menu',options=['title1','title2'], result='index'))```
